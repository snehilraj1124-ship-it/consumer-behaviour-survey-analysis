# 🛍️ Consumer Behaviour Survey & Report

## Overview

A multi-technology consumer analytics project based on a synthetic survey of 1,200 respondents. The project studies demographics, shopping preferences, discovery channels, spending, payment methods, satisfaction, loyalty, discounts and repeat-purchase behaviour.

## Technology Stack

- Python — data analysis and segmentation
- Java — object-oriented/CSV analytics
- SQL — business queries
- Microsoft Excel — PivotTables and reporting
- HTML5/CSS3 — dashboard presentation
- JavaScript — dashboard interaction

## Key Analysis Areas

- Consumer demographics
- Product category preferences
- Monthly spending
- Purchase frequency
- Discovery channels
- Payment behaviour
- Satisfaction
- Loyalty
- Discount sensitivity
- Repeat purchase behaviour

## Dataset

The repository contains 1,200 synthetic survey records. No real customer or financial information is used.

## Python

Install:
```bash
pip install -r requirements.txt
```

Run:
```bash
python survey_analysis.py
python customer_segmentation.py
python survey_quality_check.py
python generate_insights.py
```

## Java

Compile and run using the commands in `JAVA_RUN_GUIDE.md`.

## SQL

Import the CSV into a database table named `consumer_survey` and execute `consumer_behaviour_analysis.sql`.

## Excel

Use `EXCEL_DASHBOARD_GUIDE.md` to create PivotTables, charts, KPI cards and slicers.

## HTML Dashboard

Open `dashboard.html` in a browser.

## Portfolio Value

This project demonstrates an end-to-end workflow combining survey data, descriptive analytics, customer segmentation, database querying, spreadsheet reporting and web presentation.

## Disclaimer

This is an educational portfolio project using synthetic data. Results should not be treated as a real-world market survey or business forecast.

## Author

Snehil Raj
