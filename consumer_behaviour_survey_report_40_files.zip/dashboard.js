document.addEventListener("DOMContentLoaded",()=>{
 const buttons=document.querySelectorAll("button[data-view]");
 const view=document.getElementById("view");
 buttons.forEach(b=>b.addEventListener("click",()=>{
   buttons.forEach(x=>x.classList.remove("active"));
   b.classList.add("active");
   view.textContent="Selected view: "+b.dataset.view;
 }));
});
