public final class SurveyUtils {
    private SurveyUtils(){}
    public static double percentage(double part, double total){
        return total == 0 ? 0 : part * 100.0 / total;
    }
    public static double round2(double value){
        return Math.round(value * 100.0) / 100.0;
    }
}
