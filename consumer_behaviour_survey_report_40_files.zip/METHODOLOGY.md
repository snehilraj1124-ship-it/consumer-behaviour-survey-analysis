# Methodology

The project uses a synthetic cross-sectional consumer survey dataset. Respondents are segmented by demographics, income, shopping category, discovery channel, payment method, satisfaction, loyalty and repeat-purchase behaviour.

Analysis is descriptive and intended for portfolio/educational use.
