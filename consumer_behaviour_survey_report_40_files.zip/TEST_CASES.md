# Test Cases

- CSV opens successfully
- 1,200 respondent rows are present
- Respondent IDs are unique
- Monthly spend is non-negative
- HTML dashboard loads
- Java programs compile
- Python scripts load the dataset
- SQL queries reference the intended table
- Excel workbook can be used for PivotTables
