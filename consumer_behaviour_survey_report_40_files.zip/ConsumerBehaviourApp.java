public class ConsumerBehaviourApp {
    public static void main(String[] args) {
        System.out.println("Consumer Behaviour Survey & Analytics");
        System.out.println("Run ConsumerSurveyAnalytics or ChannelAnalytics for CSV analysis.");
    }
}
