# Changelog

## Version 1.0
- Added synthetic consumer survey dataset
- Added SQL analysis
- Added Python analytics
- Added Java analytics
- Added Excel dashboard guide
- Added HTML/CSS/JavaScript dashboard
- Added project documentation
