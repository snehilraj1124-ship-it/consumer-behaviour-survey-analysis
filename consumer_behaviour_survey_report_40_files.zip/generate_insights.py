import pandas as pd

df = pd.read_csv("consumer_behaviour_survey_dataset.csv")

top_category = df["Preferred_Category"].value_counts().idxmax()
top_channel = df["Discovery_Channel"].value_counts().idxmax()
top_payment = df["Payment_Method"].value_counts().idxmax()

print("Top category:", top_category)
print("Top discovery channel:", top_channel)
print("Top payment method:", top_payment)
print("Average monthly spend:", round(df["Monthly_Spend_INR"].mean(), 2))
