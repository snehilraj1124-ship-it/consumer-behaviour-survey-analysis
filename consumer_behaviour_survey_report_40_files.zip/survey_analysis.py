import pandas as pd

df = pd.read_csv("consumer_behaviour_survey_dataset.csv")

print("Respondents:", len(df))
print("\nAverage monthly spend:", round(df["Monthly_Spend_INR"].mean(), 2))
print("\nPreferred categories:")
print(df["Preferred_Category"].value_counts())
print("\nDiscovery channels:")
print(df["Discovery_Channel"].value_counts())
print("\nAverage spend by loyalty:")
print(df.groupby("Loyalty_Level")["Monthly_Spend_INR"].mean().round(2))
