# Data Privacy

All survey responses are synthetic. No real person, bank account, payment credential or personally identifiable financial information is included.
