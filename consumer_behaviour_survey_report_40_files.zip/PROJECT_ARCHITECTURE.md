# Project Architecture

Survey CSV → SQL/Python/Java analysis → Excel reporting → HTML/CSS/JavaScript dashboard.

The project demonstrates a complete consumer analytics workflow from survey data to business presentation.
