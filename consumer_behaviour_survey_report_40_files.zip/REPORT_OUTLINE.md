# Report Outline

1. Executive Summary
2. Survey Objectives
3. Respondent Demographics
4. Shopping Behaviour
5. Discovery Channels
6. Product Preferences
7. Payment Behaviour
8. Satisfaction
9. Loyalty
10. Discount Sensitivity
11. Repeat Purchase Behaviour
12. Business Implications
13. Limitations
14. Conclusion
