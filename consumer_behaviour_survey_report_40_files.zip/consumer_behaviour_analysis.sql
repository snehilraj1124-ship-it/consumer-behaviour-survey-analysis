-- Consumer Behaviour Survey Analysis
-- Suggested table: consumer_survey

SELECT Age_Group, COUNT(*) AS respondents
FROM consumer_survey GROUP BY Age_Group ORDER BY respondents DESC;

SELECT Preferred_Category, ROUND(AVG(Monthly_Spend_INR),2) AS avg_spend
FROM consumer_survey GROUP BY Preferred_Category ORDER BY avg_spend DESC;

SELECT Discovery_Channel, COUNT(*) AS respondents
FROM consumer_survey GROUP BY Discovery_Channel ORDER BY respondents DESC;

SELECT Payment_Method, COUNT(*) AS usage_count
FROM consumer_survey GROUP BY Payment_Method ORDER BY usage_count DESC;

SELECT Loyalty_Level,
       COUNT(*) AS respondents,
       ROUND(AVG(Monthly_Spend_INR),2) AS avg_monthly_spend
FROM consumer_survey
GROUP BY Loyalty_Level;

SELECT Satisfaction,
       COUNT(*) AS respondents,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM consumer_survey),2) AS share_pct
FROM consumer_survey
GROUP BY Satisfaction
ORDER BY share_pct DESC;

SELECT City,
       ROUND(AVG(Monthly_Spend_INR),2) AS avg_spend,
       ROUND(AVG(Purchase_Frequency),2) AS avg_frequency
FROM consumer_survey
GROUP BY City
ORDER BY avg_spend DESC;

SELECT Discovery_Channel,
       Preferred_Category,
       COUNT(*) AS respondents
FROM consumer_survey
GROUP BY Discovery_Channel, Preferred_Category
ORDER BY respondents DESC;

SELECT Discount_Preference_Pct,
       COUNT(*) AS respondents
FROM consumer_survey
GROUP BY Discount_Preference_Pct
ORDER BY Discount_Preference_Pct;

SELECT Repeat_Purchase,
       ROUND(AVG(Monthly_Spend_INR),2) AS avg_spend,
       COUNT(*) AS respondents
FROM consumer_survey
GROUP BY Repeat_Purchase;
