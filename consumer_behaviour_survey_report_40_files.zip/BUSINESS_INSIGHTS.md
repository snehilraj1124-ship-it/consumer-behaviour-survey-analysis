# Business Insight Framework

Potential questions addressed:
- Which categories attract the most respondents?
- Which channels are common for product discovery?
- Which payment methods are most used?
- How does spending differ by loyalty level?
- How does satisfaction vary across respondents?
- Which segments show stronger repeat-purchase behaviour?
- How sensitive are consumers to discounts?
