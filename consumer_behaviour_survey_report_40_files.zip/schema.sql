CREATE TABLE consumer_survey (
  Respondent_ID INT PRIMARY KEY,
  Age_Group VARCHAR(20),
  Gender VARCHAR(20),
  City VARCHAR(50),
  Income_Band VARCHAR(30),
  Discovery_Channel VARCHAR(50),
  Preferred_Category VARCHAR(50),
  Monthly_Spend_INR DECIMAL(12,2),
  Purchase_Frequency INT,
  Payment_Method VARCHAR(40),
  Satisfaction VARCHAR(30),
  Loyalty_Level VARCHAR(20),
  Discount_Preference_Pct DECIMAL(5,2),
  Repeat_Purchase VARCHAR(10)
);
