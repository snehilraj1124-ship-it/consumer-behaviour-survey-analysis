# SQL Query Reference

The SQL layer demonstrates:
- demographic segmentation
- category preferences
- discovery-channel analysis
- payment-method analysis
- loyalty analysis
- satisfaction analysis
- city-level spending
- channel/category cross-analysis
- discount sensitivity
- repeat-purchase behavior
