import pandas as pd

df = pd.read_csv("consumer_behaviour_survey_dataset.csv")

summary = df.groupby(["Age_Group","Loyalty_Level"]).agg(
    respondents=("Respondent_ID","count"),
    avg_spend=("Monthly_Spend_INR","mean"),
    avg_frequency=("Purchase_Frequency","mean")
).round(2)

print(summary)
summary.to_csv("customer_segment_summary.csv")
