import java.io.*;
import java.util.*;

public class ChannelAnalytics {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("consumer_behaviour_survey_dataset.csv"));
        String[] header = br.readLine().split(",", -1);
        int channel = -1;
        for (int i=0;i<header.length;i++) if (header[i].equals("Discovery_Channel")) channel=i;

        Map<String,Integer> counts = new TreeMap<>();
        String line;
        while ((line=br.readLine())!=null) {
            String[] p=line.split(",",-1);
            String c=p[channel];
            counts.put(c, counts.getOrDefault(c,0)+1);
        }
        br.close();
        counts.forEach((k,v)->System.out.println(k+" -> "+v));
    }
}
