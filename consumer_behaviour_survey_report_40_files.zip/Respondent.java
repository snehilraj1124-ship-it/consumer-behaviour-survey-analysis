public class Respondent {
    private final int id;
    private final String ageGroup;
    private final String category;
    private final double monthlySpend;

    public Respondent(int id, String ageGroup, String category, double monthlySpend) {
        this.id=id; this.ageGroup=ageGroup; this.category=category; this.monthlySpend=monthlySpend;
    }
    public int getId(){ return id; }
    public String getAgeGroup(){ return ageGroup; }
    public String getCategory(){ return category; }
    public double getMonthlySpend(){ return monthlySpend; }
}
