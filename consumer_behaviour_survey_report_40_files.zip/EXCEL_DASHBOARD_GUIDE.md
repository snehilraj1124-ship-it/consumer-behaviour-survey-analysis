# Excel Dashboard Guide

Recommended KPI cards:
- Total Respondents
- Average Monthly Spend
- Average Purchase Frequency
- Repeat Purchase Rate
- Average Discount Preference

Recommended PivotTables:
1. Age Group vs Average Spend
2. Category vs Respondent Count
3. Discovery Channel vs Respondent Count
4. Payment Method vs Respondent Count
5. Loyalty Level vs Average Spend
6. Satisfaction vs Respondent Count
7. City vs Average Spend

Recommended slicers:
- Age Group
- City
- Income Band
- Preferred Category
- Discovery Channel
- Payment Method
- Loyalty Level
