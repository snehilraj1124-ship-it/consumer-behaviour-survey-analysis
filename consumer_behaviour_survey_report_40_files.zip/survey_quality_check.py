import pandas as pd

df = pd.read_csv("consumer_behaviour_survey_dataset.csv")

print("Rows:", len(df))
print("Columns:", len(df.columns))
print("\nMissing values:")
print(df.isna().sum())
print("\nDuplicate respondent IDs:", df["Respondent_ID"].duplicated().sum())
print("Negative spending:", (df["Monthly_Spend_INR"] < 0).sum())
