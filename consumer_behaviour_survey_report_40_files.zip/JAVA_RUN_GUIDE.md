# Java Run Guide

Compile:
```bash
javac ConsumerSurveyAnalytics.java
javac ChannelAnalytics.java
javac Respondent.java
javac SurveyUtils.java
javac ConsumerBehaviourApp.java
```

Run:
```bash
java ConsumerSurveyAnalytics
java ChannelAnalytics
```
