# HTML Dashboard Guide

Open `dashboard.html` in a modern browser. The page provides an interactive summary of survey demographics, shopping behaviour and payment analysis.
