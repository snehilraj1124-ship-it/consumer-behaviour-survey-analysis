import java.io.*;
import java.util.*;

public class ConsumerSurveyAnalytics {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("consumer_behaviour_survey_dataset.csv"));
        br.readLine();
        int rows = 0;
        double totalSpend = 0;
        String line;
        while ((line = br.readLine()) != null) {
            String[] p = line.split(",", -1);
            if (p.length > 7) {
                rows++;
                totalSpend += Double.parseDouble(p[7]);
            }
        }
        br.close();
        System.out.println("Respondents: " + rows);
        System.out.printf("Average monthly spend: %.2f%n", rows == 0 ? 0 : totalSpend / rows);
    }
}
